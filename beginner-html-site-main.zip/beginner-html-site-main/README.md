# Beginner HTML Site

A simple one page website created to help complete beginners learn HyperText Markup Language (HTML) basics. This example is built up over the [HTML basics course](https://developer.mozilla.org/en-US/Learn/Getting_started_with_the_web/HTML_basics).
